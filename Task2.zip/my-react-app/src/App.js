import React, { createContext,useEffect, useState } from 'react';
import './App.css';
import axios from 'axios';
import Card from './Card'
import Grid from '@material-ui/core/Grid';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar, NavItem, NavDropdown, Button,MenuItem, Nav } from 'react-bootstrap';
import Loader from './Loader';


function App() {

  const [user, setUser] = useState(null);
  const [isLoader, setIsLoader] = useState(false);

 
  

  function handleClick() {

    setIsLoader(true);
    
    axios.get("https://reqres.in/api/users?page=1").then((response) => {
      console.log("api data recieved");
      setUser(response.data.data);
      console.log(response.data.data);  
      
      setIsLoader(false);
    });
  };
   

  return (
    <div>
       
    <Navbar  bg="dark" variant="dark">
  
    <Navbar.Brand href="#home" style ={  { paddingLeft: 10 }} >Refresh Me!!</Navbar.Brand>
    <Button variant="outline-warning" onClick={handleClick}>GET USERS</Button>
    
</Navbar>
            
      <div className="row">
        
      
        <Grid container spacing={4}>
        {user &&
          user.map((val) => {
            return (
              
                <Grid item xs={12} sm={6} md={4}> 
              <Card
                first_name={val.first_name}
                last_name={val.last_name}
                email={val.email}
                avatar={val.avatar}
              />  </Grid> 
            );
          }
          )}</Grid>
      </div>
      
      
      <Loader show={isLoader} />
 

</div>
  )
  
  ;
  
}

export default App;
